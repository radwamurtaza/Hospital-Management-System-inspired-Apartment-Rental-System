#include<stdio.h>
#include<stdlib.h>

struct {
    char name[40];
    int citizenship;
    double phone;
    int age;

    }add;

void new_user()
{

    int choice;
    FILE *ptr;

    ptr=fopen("record.txt","a+");

    system("cls");
    printf("\t\t\t -----ADD RECORD-----");
    fflush(stdin);
    printf("\nEnter Name: ");
    gets(add.name);

    printf("\nEnter the citizenship number: ");
    scanf("%d",&add.citizenship);

    printf("\nEnter the age: ");
    scanf("%d",&add.age);

    printf("\nEnter the phone number: ");
    scanf("%lf",&add.phone);
    fseek(ptr,0,SEEK_END);
    fprintf(ptr,"\n");
    fprintf(ptr,"%s\t %d\t %d\t %.0lf",add.name,add.age,add.citizenship,add.phone);

    fclose(ptr);

    printf("\nUser Added successfully!");
    printf("\nNow You can rent a Flat");
    printf("\nNOTE: Entering New user details AGAIN will not allow you to rent a flat for the previous user entered");

    printf("\n\n\n\t\tEnter 1 to go to the main menu and 0 to exit:");
    scanf("%d",&choice);
    system("cls");
    if (choice==1)
        menu();
    else
        {
          exit(0);
        }
}


void rent()
{
    int menu_exit;
    char ch;
    int flat,c_n,i;
    int choice;
    FILE *fp,*fq;
    fp=fopen("file.txt","a+");
    fq=fopen("new.txt","a+");

    while(1)
    {
        ch=fgetc(fp);
        if(ch==EOF)
        {
            printf("\n\nChoose a flat number from the given data.");
            break;
        }
        else
        {
            printf("%c",ch);
        }
    }
    printf("\n\nEnter the Flat Number you want to rent: ");
    scanf("%d",&flat);

    printf("\nEnter your citzenship Number: ");
    scanf("%d",&c_n);

    if(c_n==add.citizenship)
    {
        printf("\n\nFlat NO#%d have been rented against your citezenship number %d.\n\n",flat,c_n);
        fseek(fq,0,SEEK_END);
        fprintf(fq,"\n");
        fprintf(fq,"%d\t %d",flat,c_n);
    }
    else
    {
        printf("\nCitezenship Not found");
        printf("\nReturn to Main Menu");
    }

    fclose(fp);
    fclose(fq);
    printf("\n\nEnter 1 to go to the main menu and 0 to exit: ");
    scanf("%d",&menu_exit);
    if (menu_exit==1)
        menu();
    else
        exit(0);
}

void admin()
{
 int pass,password,choice;
 printf("\n-----This Portal is Locked by PASSWORD!-----");
 printf("\nPlease enter PASSWORD to access\n");
 scanf("%d",&pass);
 password=1234;
 if(pass!=password)
 {
     printf("\n****INCORRECT PASSWORD****");
     printf("\nPRESS '1' to return to MAIN MENU PRESS '0' to EXIT: ");
     scanf("%d",&choice);
     if(choice==1)
        menu();
     else
        exit(0);

 }
 else
 {
     access();
 }
}

void access()
{
    int main;
    int choice;
    system("cls");
    printf("\n\n------MANNAGEMENT PORTAL------");
    printf("\n\nPRESS '1' To Check ALL user records\nPRESS '2' To Check Rented Appartments\nPRESS '3' To Close the Portal\n");
    scanf("%d",&choice);

    FILE *fp;
    fp=fopen("record.txt","r");
    FILE *fq;
    fq=fopen("new.txt","r");

    switch(choice)
    {
      case 1:
            {
             char ch;
             system("cls");
             while(1)
             {
                 ch=fgetc(fp);
                 if(ch==EOF)
                 {
                     printf("\n\n\n*FILE READ COMPLETE*\n\n");
                     break;
                 }
                 else
                    printf("%c",ch);
             }
             printf("\npress '1' to retun to MAIN MENU or press '0' to exit: ");
             scanf("%d",&main);
             if (main==1)
             menu();
             else
             exit(0);
            }
        case 2:
            {
             char cha;
             system("cls");

             while(1)
             {
                 cha=fgetc(fq);
                 if(cha==EOF)
                 {
                     printf("\n*FILE READ COMPLETE*");
                     break;
                 }
                 else
                    printf("%c",cha);
             }
             printf("\npress '1' to retun to MAIN MENU or press '0' to exit: ");
             scanf("%d",&main);
             if (main==1)
             menu();
             else
             exit(0);
            }
        case 3:
            {
                menu();
            }
            }
    }


void menu(void)
{   int choice;
    system("cls");
    printf("\n\n\t\t\t\t-------APPARTMENT RENTAL SYSTEM-------");
    printf("\n\nCreated By: Sumaish, Duaa, Radwa.");
    printf("\n\n\n\t\t\t        WELCOME TO THE MAIN MENU");
    printf("\n\n\t\t1.New User(read setup file first)\n\t\t2.Rent an apartment\n\t\t3.ADMIN(RESTRICTED ACCESS)\n\t\t4.EXIT\n\n\n\n\n\t\t Enter your choice:");
    scanf("%d",&choice);

    system("cls");
    switch(choice)
    {
        case 1:new_user();
        break;
        case 2:rent();
        break;
        case 3:admin();
        break;
        case 4:exit(0);
        break;
    }
}

int main()
{
   menu();
   return 0;
}
